// Fake login validation
function loginUser(event) {
  event.preventDefault();
  let user = document.getElementById("username").value;
  let pass = document.getElementById("password").value;
  
  if(user === "admin" && pass === "1234") {
    alert("Login Successful!");
    window.location.href = "services.html";
  } else {
    alert("Invalid Login!");
  }
}

// Save application (dummy)
function submitApplication(event) {
  event.preventDefault();
  let name = document.getElementById("fullname").value;
  let appNumber = "RC" + Math.floor(Math.random() * 1000000000);
  
  localStorage.setItem(appNumber, name);
  
  document.getElementById("result").innerHTML = 
    `<p>Application Submitted Successfully!</p>
     <p>Your Application Number: <b>${appNumber}</b></p>
     <div id="qrcode"></div>`;
     
  // Generate QR
  new QRCode(document.getElementById("qrcode"), {
    text: window.location.href + "?appNumber=" + appNumber,
    width: 150,
    height: 150
  });
}

// Check status
function checkStatus(event) {
  event.preventDefault();
  let appNumber = document.getElementById("checkApp").value;
  
  if(localStorage.getItem(appNumber)) {
    document.getElementById("statusResult").innerHTML =
      `<p>Application Number: <b>${appNumber}</b></p>
       <p>Status: <b style='color:green'>Approved</b></p>`;
  } else {
    document.getElementById("statusResult").innerHTML =
      `<p style='color:red'>Application Not Found!</p>`;
  }
}